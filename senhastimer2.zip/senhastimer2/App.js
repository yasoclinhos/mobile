import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet } from "react-native";

const App = () => {
  const [senhaNormal, setSenhaNormal] = useState(0);
  const [senhaPrioritaria, setSenhaPrioritaria] = useState(0);
  const [senhaAltaPrioridade, setSenhaAltaPrioridade] = useState(0);

  const [timerNormal, setTimerNormal] = useState(90);
  const [timerPrioritaria, setTimerPrioritaria] = useState(45);
  const [timerAltaPrioridade, setTimerAltaPrioridade] = useState(30);

  
  const maxSenhas = {
    normal: 10,
    prioritario: 5,
    alta_prioridade: 3,
  };

  const gerarSenha = (tipo) => {
    if (tipo === "normal" && senhaNormal < maxSenhas.normal) {
      setSenhaNormal((prev) => prev + 1);
    } else if (tipo === "prioritario" && senhaPrioritaria < maxSenhas.prioritario) {
      setSenhaPrioritaria((prev) => prev + 1);
    } else if (tipo === "alta_prioridade" && senhaAltaPrioridade < maxSenhas.alta_prioridade) {
      setSenhaAltaPrioridade((prev) => prev + 1);
    }
  };

  useEffect(() => {
    const intervalNormal = setInterval(() => {
      gerarSenha("normal");
      setTimerNormal(90); 
    }, 90 * 1000);

    const intervalPrioritaria = setInterval(() => {
      gerarSenha("prioritario");
      setTimerPrioritaria(45); 
    }, 45 * 1000);

    const intervalAltaPrioridade = setInterval(() => {
      gerarSenha("alta_prioridade");
      setTimerAltaPrioridade(30); 
    }, 30 * 1000);

    const countdownTimers = setInterval(() => {
      setTimerNormal((prev) => (prev > 0 ? prev - 1 : 90));
      setTimerPrioritaria((prev) => (prev > 0 ? prev - 1 : 45));
      setTimerAltaPrioridade((prev) => (prev > 0 ? prev - 1 : 30));
    }, 1000);

    return () => {
      clearInterval(intervalNormal);
      clearInterval(intervalPrioritaria);
      clearInterval(intervalAltaPrioridade);
      clearInterval(countdownTimers);
    };
  }, []); 

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerador de Senhas</Text>

      <View style={styles.senhaContainer}>
        <Text style={styles.senhaText}>Senha Normal: N{String(senhaNormal).padStart(2, "0")}</Text>
        <Text style={styles.timerText}>Timer Normal: {timerNormal}s</Text>
      </View>

      <View style={styles.senhaContainer}>
        <Text style={styles.senhaText}>Senha Prioritária: P{String(senhaPrioritaria).padStart(2, "0")}</Text>
        <Text style={styles.timerText}>Timer Prioritária: {timerPrioritaria}s</Text>
      </View>

      <View style={styles.senhaContainer}>
        <Text style={styles.senhaText}>Senha Alta Prioridade: AP{String(senhaAltaPrioridade).padStart(3, "0")}</Text>
        <Text style={styles.timerText}>Timer Alta Prioridade: {timerAltaPrioridade}s</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F0F8FF",
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 40,
    textAlign: "center",
  },
  senhaContainer: {
    marginBottom: 20,
    alignItems: "center",
  },
  senhaText: {
    fontSize: 18,
    marginBottom: 5,
    color: "#333",
    fontWeight: "bold",
  },
  timerText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#555",
  },
});

export default App;
