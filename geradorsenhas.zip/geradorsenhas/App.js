import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

const App = () => {
  const [senhaNormal, setSenhaNormal] = useState(0);
  const [senhaPrioritaria, setSenhaPrioritaria] = useState(0);
  const [senhaAltaPrioridade, setSenhaAltaPrioridade] = useState(0);
  const [senhaGerada, setSenhaGerada] = useState("");

  const gerarSenha = (tipo) => {
    let novaSenha = "";
    if (tipo === "normal") {
      setSenhaNormal((prev) => prev + 1);
      novaSenha = `N${String(senhaNormal + 1).padStart(2, "0")}`;
    } else if (tipo === "prioritario") {
      setSenhaPrioritaria((prev) => prev + 1);
      novaSenha = `P${String(senhaPrioritaria + 1).padStart(2, "0")}`;
    } else if (tipo === "alta_prioridade") {
      setSenhaAltaPrioridade((prev) => prev + 1);
      novaSenha = `AP${String(senhaAltaPrioridade + 1).padStart(3, "0")}`;
    }
    setSenhaGerada(novaSenha);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerador de Senhas</Text>
      <Text style={styles.title}>Clique em um dos botões para gerar o tipo de senha que deseja!</Text>
      <View style={styles.buttonsContainer}>
        <TouchableOpacity style={[styles.button, styles.normal]} onPress={() => gerarSenha("normal")}>
          <Text style={styles.buttonText}>NORMAL</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.prioritario]} onPress={() => gerarSenha("prioritario")}>
          <Text style={styles.buttonText}>PRIORITÁRIO</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.altaPrioridade]} onPress={() => gerarSenha("alta_prioridade")}>
          <Text style={styles.buttonText}>ALTA PRIORIDADE</Text>
        </TouchableOpacity>
      </View>
      {senhaGerada ? <Text style={styles.senhaText}>Senha Gerada: {senhaGerada}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F0F8FF",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 40,
  },
  buttonsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  button: {
    padding: 15,
    borderRadius: 10,
    marginHorizontal: 10,
  },
  normal: {
    backgroundColor: "#4CAF50",
  },
  prioritario: {
    backgroundColor: "#FFC107",
  },
  altaPrioridade: {
    backgroundColor: "#F44336",
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  senhaText: {
    fontSize: 20,
    marginTop: 20,
    fontWeight: "bold",
  },
});

export default App;
